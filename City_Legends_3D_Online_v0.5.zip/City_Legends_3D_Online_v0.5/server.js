'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const WebSocket = require('ws');
const PORT = Number(process.env.PORT || 8080);
const ROOT = path.join(__dirname, 'public');
const MAX_PLAYERS = 64;
const server = http.createServer((req, res) => {
  const pathname = new URL(req.url || '/', 'http://localhost').pathname;
  if (pathname === '/health') { res.writeHead(200, {'Content-Type':'application/json; charset=utf-8'}); return res.end(JSON.stringify({ok:true, players:players.size})); }
  let decoded; try { decoded = decodeURIComponent(pathname); } catch { res.writeHead(400); return res.end('Bad request'); }
  const file = decoded === '/' ? 'index.html' : decoded.replace(/^\/+/, '');
  const full = path.resolve(ROOT, file);
  if (full !== path.join(ROOT, 'index.html') && !full.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8'};
    res.writeHead(200, {'Content-Type':types[path.extname(full)] || 'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'}); res.end(data);
  });
});
const wss = new WebSocket.Server({server, maxPayload:4096, perMessageDeflate:false});
const players = new Map();
function broadcast() {
  const packet = JSON.stringify({type:'state', players:[...players.values()]});
  for (const client of wss.clients) if (client.readyState === WebSocket.OPEN) client.send(packet);
}
wss.on('connection', ws => {
  if (players.size >= MAX_PLAYERS) { ws.close(1013, 'Server full'); return; }
  let id = null, lastMove = 0;
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if (!m || typeof m !== 'object') return;
    if (m.type === 'join' && !id) {
      id = crypto.randomUUID();
      players.set(id, {id, name:String(m.name || 'Player').replace(/[<>\u0000-\u001f]/g,'').slice(0,18) || 'Player', x:0, z:0, rot:0});
      ws.send(JSON.stringify({type:'welcome', id})); broadcast(); return;
    }
    if (m.type === 'chat' && id && players.has(id)) {
      const now = Date.now();
      if (ws._lastChat && now - ws._lastChat < 700) return;
      ws._lastChat = now;
      const text = String(m.text || '').replace(/[<>\\u0000-\\u001f]/g, '').trim().slice(0, 120);
      if (!text) return;
      const packet = JSON.stringify({type:'chat', id, name:players.get(id).name, text});
      for (const client of wss.clients) if (client.readyState === WebSocket.OPEN) client.send(packet);
      return;
    }
    if (m.type === 'move' && id && players.has(id)) {
      const now = Date.now(); if (now - lastMove < 35) return; lastMove = now;
      const p = players.get(id);
      if (Number.isFinite(m.x)) p.x = Math.max(-190, Math.min(190, m.x));
      if (Number.isFinite(m.z)) p.z = Math.max(-190, Math.min(190, m.z));
      if (Number.isFinite(m.rot)) p.rot = Math.max(-Math.PI*4, Math.min(Math.PI*4, m.rot));
    }
  });
  ws.on('close', () => { if (id) { players.delete(id); broadcast(); } });
  ws.on('error', () => { if (id) { players.delete(id); broadcast(); } });
});
const ticker = setInterval(broadcast, 100);
server.listen(PORT, '0.0.0.0', () => console.log(`City Legends 3D listening on ${PORT}`));
function shutdown(){clearInterval(ticker);wss.close(()=>server.close(()=>process.exit(0)));setTimeout(()=>process.exit(0),1500).unref();}
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
